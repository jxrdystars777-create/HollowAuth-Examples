#pragma once

#include <windows.h>
#include <wininet.h>
#include <bcrypt.h>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>
#include <cctype>

#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "bcrypt.lib")

class HollowAuth
{
public:
    static constexpr const char* SDK_VERSION = "2.1.0";

    struct ResponseData
    {
        bool success = false;
        std::string message;
        std::string error_code;
    };

    struct UserData
    {
        std::string username;
        std::string subscription;
        std::string expires;
    };

    ResponseData response;
    UserData user_data;

    bool EnableActivityLogs = true;
    DWORD ConnectTimeoutMs = 10000;
    DWORD SendTimeoutMs = 15000;
    DWORD ReceiveTimeoutMs = 20000;
    int RetryCount = 2;

private:
    std::string name;
    std::string appId;
    std::string secret;
    std::string version;
    std::string apiUrl;
    std::string cachedHwid;
    std::string cachedHwidV2;

public:
    HollowAuth(
        const std::string& appName,
        const std::string& applicationId,
        const std::string& applicationSecret,
        const std::string& applicationVersion,
        const std::string& baseApiUrl)
        : name(trim(appName)),
          appId(trim(applicationId)),
          secret(trim(applicationSecret)),
          version(trim(applicationVersion)),
          apiUrl(trimTrailingSlash(trim(baseApiUrl)))
    {
        if (name.empty() || appId.empty() || secret.empty() ||
            version.empty() || apiUrl.empty())
        {
            response.success = false;
            response.message = "Los datos de inicializacion de HollowAuth no pueden estar vacios.";
            response.error_code = "INVALID_SDK_CONFIGURATION";
        }
    }

    void init()
    {
        std::string body = "{";
        appendJsonField(body, "name", name);
        appendJsonField(body, "appId", appId);
        appendJsonField(body, "secret", secret);
        appendJsonField(body, "version", version);
        appendClientMetadata(body);
        finishJson(body);

        applyResponse(post("/init", body), false, "");
    }

    void login(const std::string& username, const std::string& password)
    {
        std::string body = "{";
        appendJsonField(body, "appId", appId);
        appendJsonField(body, "secret", secret);
        appendJsonField(body, "username", username);
        appendJsonField(body, "password", password);
        appendJsonField(body, "hwid", getHWID());
        appendJsonField(body, "hwidV2", getHWIDV2());
        appendClientMetadata(body);
        finishJson(body);

        applyResponse(post("/login", body), true, username);
    }

    void registerUser(
        const std::string& username,
        const std::string& password,
        const std::string& key)
    {
        std::string body = "{";
        appendJsonField(body, "appId", appId);
        appendJsonField(body, "secret", secret);
        appendJsonField(body, "username", username);
        appendJsonField(body, "password", password);
        appendJsonField(body, "license", key);
        appendJsonField(body, "hwid", getHWID());
        appendJsonField(body, "hwidV2", getHWIDV2());
        appendClientMetadata(body);
        finishJson(body);

        applyResponse(post("/register", body), true, username);
    }

    void license(const std::string& key)
    {
        std::string body = "{";
        appendJsonField(body, "appId", appId);
        appendJsonField(body, "secret", secret);
        appendJsonField(body, "license", key);
        appendJsonField(body, "hwid", getHWID());
        appendJsonField(body, "hwidV2", getHWIDV2());
        appendClientMetadata(body);
        finishJson(body);

        applyResponse(post("/license", body), true, "License User");
    }

    std::string variable(const std::string& variableName)
    {
        std::string body = "{";
        appendJsonField(body, "appId", appId);
        appendJsonField(body, "secret", secret);
        appendJsonField(body, "name", variableName);
        appendJsonField(body, "sdkVersion", SDK_VERSION);
        appendJsonField(body, "appVersion", version);
        finishJson(body);

        const std::string result = post("/variable", body);
        applyResponse(result, false, "");

        return response.success ? getJsonString(result, "value") : "";
    }

    std::string get_hwid()
    {
        return getHWID();
    }

    std::string get_hwid_v2()
    {
        return getHWIDV2();
    }

private:
    void applyResponse(
        const std::string& result,
        bool authenticationOperation,
        const std::string& fallbackUsername)
    {
        response.success = getJsonBool(result, "success");
        response.message = getJsonString(result, "message");
        response.error_code = getJsonString(result, "errorCode");

        if (response.error_code.empty())
            response.error_code = getJsonString(result, "error_code");

        if (!authenticationOperation)
            return;

        if (!response.success)
        {
            user_data = UserData();
            return;
        }

        user_data.username = getJsonString(result, "username");
        if (user_data.username.empty())
            user_data.username = fallbackUsername;

        user_data.subscription = getJsonString(result, "subscription");
        user_data.expires = getJsonString(result, "expiresAt");
    }

    std::string post(const std::string& endpoint, const std::string& body)
    {
        const int attempts = std::max(1, RetryCount + 1);
        std::string lastError =
            "{\"success\":false,\"message\":\"No se pudo conectar con HollowAuth.\","
            "\"errorCode\":\"NETWORK_ERROR\"}";

        for (int attempt = 0; attempt < attempts; ++attempt)
        {
            DWORD statusCode = 0;
            bool transientFailure = false;

            const std::string result =
                sendOnce(endpoint, body, statusCode, transientFailure);

            if (!result.empty())
                lastError = result;

            if (!transientFailure || attempt + 1 >= attempts)
                return lastError;

            Sleep(static_cast<DWORD>(250 * (1 << std::min(attempt, 3))));
        }

        return lastError;
    }

    std::string sendOnce(
        const std::string& endpoint,
        const std::string& body,
        DWORD& statusCode,
        bool& transientFailure)
    {
        statusCode = 0;
        transientFailure = false;

        const std::string fullUrl = apiUrl + endpoint;

        URL_COMPONENTSA parts{};
        char hostName[256]{};
        char urlPath[2048]{};
        char extraInfo[1024]{};

        parts.dwStructSize = sizeof(parts);
        parts.lpszHostName = hostName;
        parts.dwHostNameLength = static_cast<DWORD>(sizeof(hostName));
        parts.lpszUrlPath = urlPath;
        parts.dwUrlPathLength = static_cast<DWORD>(sizeof(urlPath));
        parts.lpszExtraInfo = extraInfo;
        parts.dwExtraInfoLength = static_cast<DWORD>(sizeof(extraInfo));

        if (!InternetCrackUrlA(fullUrl.c_str(), 0, 0, &parts))
            return makeError("La URL de HollowAuth no es valida.", "INVALID_URL");

        const bool isHttps = parts.nScheme == INTERNET_SCHEME_HTTPS;

        HINTERNET internet = InternetOpenA(
            ("HollowAuth-Cpp-SDK/" + std::string(SDK_VERSION)).c_str(),
            INTERNET_OPEN_TYPE_PRECONFIG,
            nullptr,
            nullptr,
            0);

        if (!internet)
        {
            transientFailure = true;
            return makeError("No se pudo inicializar la conexion.", "INTERNET_OPEN_FAILED");
        }

        InternetSetOptionA(
            internet,
            INTERNET_OPTION_CONNECT_TIMEOUT,
            &ConnectTimeoutMs,
            sizeof(ConnectTimeoutMs));

        InternetSetOptionA(
            internet,
            INTERNET_OPTION_SEND_TIMEOUT,
            &SendTimeoutMs,
            sizeof(SendTimeoutMs));

        InternetSetOptionA(
            internet,
            INTERNET_OPTION_RECEIVE_TIMEOUT,
            &ReceiveTimeoutMs,
            sizeof(ReceiveTimeoutMs));

        HINTERNET connection = InternetConnectA(
            internet,
            hostName,
            parts.nPort,
            nullptr,
            nullptr,
            INTERNET_SERVICE_HTTP,
            0,
            0);

        if (!connection)
        {
            transientFailure = true;
            InternetCloseHandle(internet);
            return makeError("No se pudo conectar con el servidor.", "CONNECTION_FAILED");
        }

        DWORD flags =
            INTERNET_FLAG_RELOAD |
            INTERNET_FLAG_NO_CACHE_WRITE |
            INTERNET_FLAG_NO_UI |
            INTERNET_FLAG_KEEP_CONNECTION;

        if (isHttps)
            flags |= INTERNET_FLAG_SECURE;

        std::string requestPath = urlPath;
        if (parts.dwExtraInfoLength > 0)
            requestPath += extraInfo;

        HINTERNET request = HttpOpenRequestA(
            connection,
            "POST",
            requestPath.c_str(),
            nullptr,
            nullptr,
            nullptr,
            flags,
            0);

        if (!request)
        {
            transientFailure = true;
            InternetCloseHandle(connection);
            InternetCloseHandle(internet);
            return makeError("No se pudo crear la solicitud HTTP.", "REQUEST_CREATE_FAILED");
        }

        const std::string headers =
            "Content-Type: application/json\r\n"
            "Accept: application/json\r\n"
            "X-HollowAuth-SDK-Version: " + std::string(SDK_VERSION) + "\r\n";

        const BOOL sent = HttpSendRequestA(
            request,
            headers.c_str(),
            static_cast<DWORD>(headers.size()),
            const_cast<char*>(body.data()),
            static_cast<DWORD>(body.size()));

        if (!sent)
        {
            transientFailure = true;
            InternetCloseHandle(request);
            InternetCloseHandle(connection);
            InternetCloseHandle(internet);
            return makeError(
                "No se pudo enviar la solicitud a HollowAuth.",
                "REQUEST_SEND_FAILED");
        }

        DWORD statusSize = sizeof(statusCode);
        HttpQueryInfoA(
            request,
            HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER,
            &statusCode,
            &statusSize,
            nullptr);

        transientFailure =
            statusCode == 408 ||
            statusCode == 425 ||
            statusCode == 429 ||
            statusCode >= 500;

        std::string responseText;
        responseText.reserve(4096);

        char buffer[4096];
        DWORD bytesRead = 0;
        const size_t maxResponseSize = 1024 * 1024;

        while (InternetReadFile(
            request,
            buffer,
            static_cast<DWORD>(sizeof(buffer)),
            &bytesRead))
        {
            if (bytesRead == 0)
                break;

            if (responseText.size() + bytesRead > maxResponseSize)
            {
                responseText = makeError(
                    "La respuesta del servidor excedio el tamano permitido.",
                    "RESPONSE_TOO_LARGE");
                transientFailure = false;
                break;
            }

            responseText.append(buffer, bytesRead);
        }

        InternetCloseHandle(request);
        InternetCloseHandle(connection);
        InternetCloseHandle(internet);

        if (responseText.empty())
        {
            transientFailure = true;
            return makeError(
                "HollowAuth devolvio una respuesta vacia.",
                "EMPTY_RESPONSE");
        }

        if (responseText.find("\"success\"") == std::string::npos)
        {
            if (statusCode >= 400)
            {
                return makeError(
                    httpStatusMessage(statusCode),
                    "HTTP_" + std::to_string(statusCode));
            }

            return makeError(
                "HollowAuth devolvio una respuesta invalida.",
                "INVALID_RESPONSE");
        }

        return responseText;
    }

    void appendClientMetadata(std::string& json)
    {
        appendJsonField(json, "sdkVersion", SDK_VERSION);
        appendJsonField(json, "appVersion", version);

        if (!EnableActivityLogs)
            return;

        appendJsonField(json, "deviceName", getComputerName());
        appendJsonField(json, "pcUsername", getWindowsUsername());
        appendJsonField(json, "osName", getOperatingSystemName());
        appendJsonField(json, "architecture", getProcessArchitecture());
    }

    std::string getHWID()
    {
        if (!cachedHwid.empty())
            return cachedHwid;

        HKEY key = nullptr;
        char value[256]{};
        DWORD valueLength = sizeof(value);
        DWORD valueType = 0;

        LONG result = RegOpenKeyExA(
            HKEY_LOCAL_MACHINE,
            "SOFTWARE\\Microsoft\\Cryptography",
            0,
            KEY_READ | KEY_WOW64_64KEY,
            &key);

        if (result == ERROR_SUCCESS)
        {
            result = RegQueryValueExA(
                key,
                "MachineGuid",
                nullptr,
                &valueType,
                reinterpret_cast<LPBYTE>(value),
                &valueLength);

            RegCloseKey(key);

            if (result == ERROR_SUCCESS &&
                (valueType == REG_SZ || valueType == REG_EXPAND_SZ))
            {
                cachedHwid = safeMetadata(std::string(value), 200);
                if (!cachedHwid.empty())
                    return cachedHwid;
            }
        }

        cachedHwid = getComputerName();
        if (cachedHwid.empty())
            cachedHwid = "Unknown-HWID";

        return cachedHwid;
    }


    std::string getHWIDV2()
    {
        if (!cachedHwidV2.empty()) return cachedHwidV2;

        const std::string firmwareUuid = getFirmwareUuidRawHex();
        const std::string source = isReliableFirmwareUuid(firmwareUuid)
            ? "FWUUID:" + firmwareUuid
            : "MACHINEGUID:" + normalizeHardwareValue(getMachineGuid()) +
              "|VOLUME:" + getSystemVolumeSerial();

        cachedHwidV2 = "HOLLOW2-" + sha256Hex(source).substr(0, 48);
        return cachedHwidV2;
    }

    static std::string getMachineGuid()
    {
        HKEY key = nullptr;
        char value[256]{};
        DWORD valueLength = sizeof(value);
        DWORD valueType = 0;

        LONG result = RegOpenKeyExA(
            HKEY_LOCAL_MACHINE,
            "SOFTWARE\\Microsoft\\Cryptography",
            0, KEY_READ | KEY_WOW64_64KEY, &key);

        if (result != ERROR_SUCCESS) return "";

        result = RegQueryValueExA(
            key, "MachineGuid", nullptr, &valueType,
            reinterpret_cast<LPBYTE>(value), &valueLength);

        RegCloseKey(key);

        if (result != ERROR_SUCCESS ||
            (valueType != REG_SZ && valueType != REG_EXPAND_SZ)) return "";

        return std::string(value);
    }

    static std::string normalizeHardwareValue(const std::string& value)
    {
        std::string output;
        for (unsigned char c : value)
            if (!std::isspace(c))
                output.push_back(static_cast<char>(std::toupper(c)));
        return output;
    }

    static std::string getFirmwareUuidRawHex()
    {
        const DWORD provider = 'BMSR';
        const UINT size = GetSystemFirmwareTable(provider, 0, nullptr, 0);
        if (size < 8 || size > 1024 * 1024) return "";

        std::vector<BYTE> raw(size);
        const UINT written = GetSystemFirmwareTable(provider, 0, raw.data(), size);
        if (written < 8) return "";

        DWORD tableLength = 0;
        memcpy(&tableLength, raw.data() + 4, sizeof(tableLength));

        size_t offset = 8;
        const size_t end = std::min<size_t>(raw.size(), offset + tableLength);

        while (offset + 4 <= end)
        {
            const BYTE type = raw[offset];
            const size_t length = raw[offset + 1];
            if (length < 4 || offset + length > end) break;

            if (type == 1 && length >= 24)
            {
                const BYTE* uuid = raw.data() + offset + 8;
                bool allZero = true, allFF = true;
                std::ostringstream hex;
                hex << std::uppercase << std::hex;
                hex.fill('0');

                for (int i = 0; i < 16; ++i)
                {
                    allZero = allZero && uuid[i] == 0x00;
                    allFF = allFF && uuid[i] == 0xFF;
                    hex.width(2);
                    hex << static_cast<int>(uuid[i]);
                }

                if (!allZero && !allFF) return hex.str();
            }

            size_t next = offset + length;
            while (next + 1 < end && !(raw[next] == 0 && raw[next + 1] == 0)) ++next;
            offset = next + 2;
            if (type == 127) break;
        }

        return "";
    }

    static bool isReliableFirmwareUuid(const std::string& value)
    {
        if (value.size() != 32) return false;

        const bool allZero = std::all_of(value.begin(), value.end(), [](char c) { return c == '0'; });
        const bool allFF = std::all_of(value.begin(), value.end(), [](char c) { return c == 'F'; });

        return !allZero && !allFF;
    }

    static std::string getSystemVolumeSerial()
    {
        char windowsDirectory[MAX_PATH]{};
        if (!GetWindowsDirectoryA(windowsDirectory, static_cast<UINT>(sizeof(windowsDirectory)))) return "";

        char root[] = "C:\\";
        if (windowsDirectory[1] == ':') root[0] = windowsDirectory[0];

        DWORD serial = 0;
        if (!GetVolumeInformationA(root, nullptr, 0, &serial, nullptr, nullptr, nullptr, 0)) return "";

        char text[9]{};
        wsprintfA(text, "%08X", serial);
        return text;
    }

    static std::string sha256Hex(const std::string& value)
    {
        BCRYPT_ALG_HANDLE algorithm = nullptr;
        BCRYPT_HASH_HANDLE hash = nullptr;
        DWORD objectLength = 0, hashLength = 0, bytes = 0;
        std::vector<BYTE> hashObject, digest;
        std::string output;

        if (BCryptOpenAlgorithmProvider(&algorithm, BCRYPT_SHA256_ALGORITHM, nullptr, 0) != 0) return "";

        if (BCryptGetProperty(algorithm, BCRYPT_OBJECT_LENGTH,
                reinterpret_cast<PUCHAR>(&objectLength), sizeof(objectLength), &bytes, 0) != 0 ||
            BCryptGetProperty(algorithm, BCRYPT_HASH_LENGTH,
                reinterpret_cast<PUCHAR>(&hashLength), sizeof(hashLength), &bytes, 0) != 0)
        {
            BCryptCloseAlgorithmProvider(algorithm, 0);
            return "";
        }

        hashObject.resize(objectLength);
        digest.resize(hashLength);

        if (BCryptCreateHash(algorithm, &hash, hashObject.data(), objectLength, nullptr, 0, 0) == 0)
        {
            BCryptHashData(hash,
                reinterpret_cast<PUCHAR>(const_cast<char*>(value.data())),
                static_cast<ULONG>(value.size()), 0);

            if (BCryptFinishHash(hash, digest.data(), hashLength, 0) == 0)
            {
                static const char digits[] = "0123456789ABCDEF";
                output.reserve(digest.size() * 2);
                for (BYTE b : digest)
                {
                    output.push_back(digits[(b >> 4) & 0x0F]);
                    output.push_back(digits[b & 0x0F]);
                }
            }

            BCryptDestroyHash(hash);
        }

        BCryptCloseAlgorithmProvider(algorithm, 0);
        return output;
    }

    static std::string getComputerName()
    {
        char value[MAX_COMPUTERNAME_LENGTH + 1]{};
        DWORD length = static_cast<DWORD>(sizeof(value));

        return GetComputerNameA(value, &length)
            ? safeMetadata(std::string(value, length), 80)
            : "Unknown";
    }

    static std::string getWindowsUsername()
    {
        char value[256]{};
        DWORD length = static_cast<DWORD>(sizeof(value));

        if (GetUserNameA(value, &length) && length > 0)
            return safeMetadata(std::string(value), 80);

        return "Unknown";
    }

    static std::string getProcessArchitecture()
    {
#ifdef _WIN64
        return "x64";
#else
        return "x86";
#endif
    }

    static std::string getOperatingSystemName()
    {
        typedef LONG(WINAPI* RtlGetVersionPtr)(PRTL_OSVERSIONINFOW);

        HMODULE module = GetModuleHandleW(L"ntdll.dll");
        if (module)
        {
            RtlGetVersionPtr rtlGetVersion =
                reinterpret_cast<RtlGetVersionPtr>(
                    GetProcAddress(module, "RtlGetVersion"));

            if (rtlGetVersion)
            {
                RTL_OSVERSIONINFOW info{};
                info.dwOSVersionInfoSize = sizeof(info);

                if (rtlGetVersion(&info) == 0)
                {
                    std::ostringstream text;

                    if (info.dwMajorVersion == 10 &&
                        info.dwMinorVersion == 0 &&
                        info.dwBuildNumber >= 22000)
                    {
                        text << "Windows 11";
                    }
                    else if (info.dwMajorVersion == 10)
                    {
                        text << "Windows 10";
                    }
                    else
                    {
                        text << "Windows "
                             << info.dwMajorVersion
                             << "."
                             << info.dwMinorVersion;
                    }

                    text << " (Build " << info.dwBuildNumber << ")";
                    return text.str();
                }
            }
        }

        return "Windows";
    }

    static std::string safeMetadata(
        const std::string& value,
        size_t maxLength)
    {
        std::string clean;
        clean.reserve(std::min(value.size(), maxLength));

        for (unsigned char c : value)
        {
            if (c >= 32 && c != 127)
                clean.push_back(static_cast<char>(c));

            if (clean.size() >= maxLength)
                break;
        }

        return trim(clean);
    }

    static void appendJsonField(
        std::string& json,
        const std::string& key,
        const std::string& value)
    {
        if (json.size() > 1 && json.back() != '{')
            json += ",";

        json += "\"" + escapeJson(key) + "\":\"" +
                escapeJson(value) + "\"";
    }

    static void finishJson(std::string& json)
    {
        json += "}";
    }

    static std::string makeError(
        const std::string& message,
        const std::string& errorCode)
    {
        return "{\"success\":false,\"message\":\"" +
               escapeJson(message) +
               "\",\"errorCode\":\"" +
               escapeJson(errorCode) +
               "\"}";
    }

    static std::string httpStatusMessage(DWORD status)
    {
        switch (status)
        {
        case 400:
            return "La solicitud enviada a HollowAuth no es valida.";
        case 401:
            return "Las credenciales de la aplicacion no son validas.";
        case 403:
            return "HollowAuth rechazo esta operacion.";
        case 404:
            return "No se encontro el recurso solicitado.";
        case 429:
            return "Se realizaron demasiadas solicitudes.";
        case 500:
        case 502:
        case 503:
        case 504:
            return "HollowAuth esta temporalmente ocupado.";
        default:
            return "El servidor respondio con el codigo " +
                   std::to_string(status) + ".";
        }
    }

    static std::string trim(const std::string& value)
    {
        size_t begin = 0;
        while (begin < value.size() &&
               std::isspace(static_cast<unsigned char>(value[begin])))
        {
            ++begin;
        }

        size_t end = value.size();
        while (end > begin &&
               std::isspace(static_cast<unsigned char>(value[end - 1])))
        {
            --end;
        }

        return value.substr(begin, end - begin);
    }

    static std::string trimTrailingSlash(std::string value)
    {
        while (!value.empty() &&
               (value.back() == '/' || value.back() == '\\'))
        {
            value.pop_back();
        }

        return value;
    }

    static std::string escapeJson(const std::string& value)
    {
        std::string output;
        output.reserve(value.size() + 8);

        for (unsigned char c : value)
        {
            switch (c)
            {
            case '"':
                output += "\\\"";
                break;
            case '\\':
                output += "\\\\";
                break;
            case '\b':
                output += "\\b";
                break;
            case '\f':
                output += "\\f";
                break;
            case '\n':
                output += "\\n";
                break;
            case '\r':
                output += "\\r";
                break;
            case '\t':
                output += "\\t";
                break;
            default:
                if (c < 0x20)
                {
                    char encoded[7]{};
                    wsprintfA(encoded, "\\u%04X", c);
                    output += encoded;
                }
                else
                {
                    output.push_back(static_cast<char>(c));
                }
                break;
            }
        }

        return output;
    }

    static bool getJsonBool(
        const std::string& json,
        const std::string& key)
    {
        size_t position = findJsonValue(json, key);
        if (position == std::string::npos)
            return false;

        return json.compare(position, 4, "true") == 0;
    }

    static std::string getJsonString(
        const std::string& json,
        const std::string& key)
    {
        size_t position = findJsonValue(json, key);
        if (position == std::string::npos ||
            position >= json.size() ||
            json[position] != '"')
        {
            return "";
        }

        ++position;
        std::string output;

        while (position < json.size())
        {
            char current = json[position++];

            if (current == '"')
                break;

            if (current != '\\')
            {
                output.push_back(current);
                continue;
            }

            if (position >= json.size())
                break;

            char escaped = json[position++];

            switch (escaped)
            {
            case '"':
                output.push_back('"');
                break;
            case '\\':
                output.push_back('\\');
                break;
            case '/':
                output.push_back('/');
                break;
            case 'b':
                output.push_back('\b');
                break;
            case 'f':
                output.push_back('\f');
                break;
            case 'n':
                output.push_back('\n');
                break;
            case 'r':
                output.push_back('\r');
                break;
            case 't':
                output.push_back('\t');
                break;
            default:
                output.push_back(escaped);
                break;
            }
        }

        return output;
    }

    static size_t findJsonValue(
        const std::string& json,
        const std::string& key)
    {
        const std::string token = "\"" + key + "\"";
        size_t position = json.find(token);

        if (position == std::string::npos)
            return position;

        position = json.find(':', position + token.size());
        if (position == std::string::npos)
            return position;

        ++position;

        while (position < json.size() &&
               std::isspace(static_cast<unsigned char>(json[position])))
        {
            ++position;
        }

        return position;
    }
};
