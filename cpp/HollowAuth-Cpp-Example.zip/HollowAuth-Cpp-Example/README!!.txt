Para usar este example:
Abre Visual Studio 2022.
Crea un proyecto C++ Windows Desktop Application vacío.
Agrega main.cpp y HollowAuth.hpp.
Cambia las credenciales de HollowAuth.
Compila en x64.