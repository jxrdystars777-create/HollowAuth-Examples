#include <windows.h>
#include <string>
#include <gdiplus.h>
#include "HollowAuth.hpp"

#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdiplus.lib")

using namespace Gdiplus;

#ifndef EM_SETCUEBANNER
#define EM_SETCUEBANNER 0x1501
#endif

#define ID_TXT_USER      1001
#define ID_TXT_PASS      1002
#define ID_TXT_KEY       1003
#define ID_BTN_REGISTER  1004
#define ID_BTN_LOGIN     1005
#define ID_BTN_KEYLOGIN  1006
#define ID_BTN_CLOSE     1007

HINSTANCE g_hInstance;
HWND g_loginWindow;

HWND txtUser;
HWND txtPass;
HWND txtKey;

HWND btnRegister;
HWND btnLogin;
HWND btnKeyLogin;
HWND btnClose;

ULONG_PTR g_gdiplusToken;

std::string g_statusText = "Status: waiting...";
COLORREF g_statusColor = RGB(180, 180, 180);

HollowAuth HollowApp(
    "HollowKnight",
    "1834a481-f700-4574-89e7-cb65c029312b",
    "a96d57b7175314f3fe7b498260d77fd42151c9e01a51371ed703bcb880062da8",
    "1.0",
    "https://hollowauth.onrender.com/api/client"
);

std::string GetTextFromInput(HWND input)
{
    char buffer[512];
    GetWindowTextA(input, buffer, sizeof(buffer));
    return std::string(buffer);
}

void SetStatus(HWND hwnd, const std::string& text, COLORREF color)
{
    g_statusText = "Status: " + text;
    g_statusColor = color;
    InvalidateRect(hwnd, NULL, TRUE);
}

void SetRoundedWindow(HWND hwnd, int radius)
{
    RECT rc;
    GetWindowRect(hwnd, &rc);

    int width = rc.right - rc.left;
    int height = rc.bottom - rc.top;

    HRGN region = CreateRoundRectRgn(0, 0, width, height, radius, radius);
    SetWindowRgn(hwnd, region, TRUE);
}

HFONT CreateFontCustom(int size, int weight)
{
    return CreateFontA(
        size,
        0,
        0,
        0,
        weight,
        FALSE,
        FALSE,
        FALSE,
        DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS,
        CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY,
        DEFAULT_PITCH,
        "Segoe UI"
    );
}

void ApplyEditStyle(HWND edit)
{
    HFONT editFont = CreateFontCustom(15, FW_SEMIBOLD);
    SendMessageA(edit, WM_SETFONT, (WPARAM)editFont, TRUE);
}

void DrawRoundRect(HDC hdc, RECT rc, COLORREF fill, COLORREF border, int radius)
{
    HBRUSH brush = CreateSolidBrush(fill);
    HPEN pen = CreatePen(PS_SOLID, 1, border);

    HGDIOBJ oldBrush = SelectObject(hdc, brush);
    HGDIOBJ oldPen = SelectObject(hdc, pen);

    RoundRect(hdc, rc.left, rc.top, rc.right, rc.bottom, radius, radius);

    SelectObject(hdc, oldBrush);
    SelectObject(hdc, oldPen);

    DeleteObject(brush);
    DeleteObject(pen);
}

void DrawLogoPng(HDC hdc, int x, int y, int width, int height)
{
    wchar_t exePath[MAX_PATH];
    GetModuleFileNameW(NULL, exePath, MAX_PATH);

    std::wstring folder = exePath;
    size_t lastSlash = folder.find_last_of(L"\/");

    if (lastSlash != std::wstring::npos)
    {
        folder = folder.substr(0, lastSlash + 1);
    }

    std::wstring logoPath = folder + L"logo.png";

    Graphics graphics(hdc);
    graphics.SetInterpolationMode(InterpolationModeHighQualityBicubic);
    graphics.SetSmoothingMode(SmoothingModeAntiAlias);

    Image logo(logoPath.c_str());

    if (logo.GetLastStatus() == Ok)
    {
        graphics.DrawImage(&logo, x, y, width, height);
    }
    else
    {
        HFONT logoFont = CreateFontCustom(28, FW_BLACK);
        HGDIOBJ oldFont = SelectObject(hdc, logoFont);

        SetBkMode(hdc, TRANSPARENT);
        SetTextColor(hdc, RGB(255, 255, 255));
        TextOutA(hdc, x, y + 8, "HW", 2);

        SelectObject(hdc, oldFont);
        DeleteObject(logoFont);
    }
}

void OpenMainWindow();

void CreateLoginControls(HWND hwnd)
{
    txtUser = CreateWindowExA(
        0,
        "EDIT",
        "",
        WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
        48,
        177,
        244,
        24,
        hwnd,
        (HMENU)ID_TXT_USER,
        g_hInstance,
        NULL
    );

    txtPass = CreateWindowExA(
        0,
        "EDIT",
        "",
        WS_CHILD | WS_VISIBLE | ES_PASSWORD | ES_AUTOHSCROLL,
        48,
        252,
        244,
        24,
        hwnd,
        (HMENU)ID_TXT_PASS,
        g_hInstance,
        NULL
    );

    txtKey = CreateWindowExA(
        0,
        "EDIT",
        "",
        WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL,
        48,
        327,
        244,
        24,
        hwnd,
        (HMENU)ID_TXT_KEY,
        g_hInstance,
        NULL
    );

    SendMessageW(txtUser, EM_SETCUEBANNER, FALSE, (LPARAM)L"Enter username");
    SendMessageW(txtPass, EM_SETCUEBANNER, FALSE, (LPARAM)L"Enter password");
    SendMessageW(txtKey, EM_SETCUEBANNER, FALSE, (LPARAM)L"Enter license key");

    ApplyEditStyle(txtUser);
    ApplyEditStyle(txtPass);
    ApplyEditStyle(txtKey);

    btnRegister = CreateWindowExA(
        0,
        "BUTTON",
        "Register",
        WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
        42,
        382,
        120,
        42,
        hwnd,
        (HMENU)ID_BTN_REGISTER,
        g_hInstance,
        NULL
    );

    btnLogin = CreateWindowExA(
        0,
        "BUTTON",
        "Login",
        WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
        178,
        382,
        120,
        42,
        hwnd,
        (HMENU)ID_BTN_LOGIN,
        g_hInstance,
        NULL
    );

    btnKeyLogin = CreateWindowExA(
        0,
        "BUTTON",
        "Key Login",
        WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
        42,
        438,
        256,
        42,
        hwnd,
        (HMENU)ID_BTN_KEYLOGIN,
        g_hInstance,
        NULL
    );

    btnClose = CreateWindowExA(
        0,
        "BUTTON",
        "X",
        WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
        300,
        14,
        24,
        24,
        hwnd,
        (HMENU)ID_BTN_CLOSE,
        g_hInstance,
        NULL
    );
}

void DrawLoginUI(HWND hwnd, HDC hdc)
{
    RECT client;
    GetClientRect(hwnd, &client);

    HBRUSH bgBrush = CreateSolidBrush(RGB(0, 0, 0));
    FillRect(hdc, &client, bgBrush);
    DeleteObject(bgBrush);

    SetBkMode(hdc, TRANSPARENT);

    HFONT titleFont = CreateFontCustom(24, FW_BOLD);
    HFONT subFont = CreateFontCustom(14, FW_SEMIBOLD);
    HFONT labelFont = CreateFontCustom(14, FW_BOLD);
    HFONT statusFont = CreateFontCustom(13, FW_BOLD);

    DrawLogoPng(hdc, 42, 34, 52, 52);

    SelectObject(hdc, titleFont);
    SetTextColor(hdc, RGB(255, 255, 255));
    TextOutA(hdc, 110, 39, "HollowAuth", 10);

    SelectObject(hdc, subFont);
    SetTextColor(hdc, RGB(120, 130, 150));
    TextOutA(hdc, 111, 68, "Full Example - Secure Auth", 26);

    SelectObject(hdc, labelFont);
    SetTextColor(hdc, RGB(235, 235, 235));

    TextOutA(hdc, 42, 138, "Username", 8);
    TextOutA(hdc, 42, 213, "Password", 8);
    TextOutA(hdc, 42, 288, "License Key", 11);

    RECT input1 = { 40, 164, 300, 208 };
    RECT input2 = { 40, 239, 300, 283 };
    RECT input3 = { 40, 314, 300, 358 };

    DrawRoundRect(hdc, input1, RGB(0, 0, 0), RGB(235, 235, 235), 10);
    DrawRoundRect(hdc, input2, RGB(0, 0, 0), RGB(90, 90, 90), 10);
    DrawRoundRect(hdc, input3, RGB(0, 0, 0), RGB(90, 90, 90), 10);

    SelectObject(hdc, statusFont);
    SetTextColor(hdc, g_statusColor);
    TextOutA(hdc, 24, 520, g_statusText.c_str(), (int)g_statusText.length());

    DeleteObject(titleFont);
    DeleteObject(subFont);
    DeleteObject(labelFont);
    DeleteObject(statusFont);
}

void DrawOwnerButton(LPDRAWITEMSTRUCT item)
{
    HDC hdc = item->hDC;
    RECT rc = item->rcItem;

    bool pressed = (item->itemState & ODS_SELECTED) != 0;
    bool hot = (item->itemState & ODS_HOTLIGHT) != 0;

    int controlId = (int)item->CtlID;

    COLORREF fill = RGB(18, 18, 18);
    COLORREF border = RGB(95, 95, 95);
    COLORREF text = RGB(245, 245, 245);

    if (pressed)
    {
        fill = RGB(35, 35, 35);
        border = RGB(135, 135, 135);
    }

    if (hot)
    {
        border = RGB(150, 150, 150);
    }

    if (controlId == ID_BTN_CLOSE)
    {
        fill = RGB(0, 0, 0);
        border = RGB(0, 0, 0);
        text = RGB(210, 210, 210);

        if (pressed || hot)
        {
            text = RGB(255, 80, 80);
        }
    }

    HBRUSH brush = CreateSolidBrush(fill);
    HPEN pen = CreatePen(PS_SOLID, 1, border);

    HGDIOBJ oldBrush = SelectObject(hdc, brush);
    HGDIOBJ oldPen = SelectObject(hdc, pen);

    RoundRect(hdc, rc.left, rc.top, rc.right, rc.bottom, 12, 12);

    SelectObject(hdc, oldBrush);
    SelectObject(hdc, oldPen);

    DeleteObject(brush);
    DeleteObject(pen);

    char textBuffer[128];
    GetWindowTextA(item->hwndItem, textBuffer, sizeof(textBuffer));

    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, text);

    HFONT font = CreateFontCustom(13, FW_BOLD);
    HGDIOBJ oldFont = SelectObject(hdc, font);

    DrawTextA(
        hdc,
        textBuffer,
        -1,
        &rc,
        DT_CENTER | DT_VCENTER | DT_SINGLELINE
    );

    SelectObject(hdc, oldFont);
    DeleteObject(font);
}

void GoToMain(HWND hwnd)
{
    std::string maintenance = HollowApp.variable("maintenance");

    if (maintenance == "true" || maintenance == "1" || maintenance == "on")
        
    {
        SetStatus(hwnd, "Application is under maintenance.", RGB(255, 210, 50));
        MessageBoxA(hwnd, "This application is currently under maintenance.", "HollowAuth", MB_OK | MB_ICONWARNING);
        return;
    }

    ShowWindow(hwnd, SW_HIDE);
    OpenMainWindow();
}

LRESULT CALLBACK LoginWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_CREATE:
    {
        SetRoundedWindow(hwnd, 18);
        CreateLoginControls(hwnd);

        HollowApp.init();

        if (HollowApp.response.success)
        {
            SetStatus(hwnd, "Application initialized successfully.", RGB(0, 255, 120));
        }
        else
        {
            SetStatus(hwnd, HollowApp.response.message, RGB(255, 45, 45));
        }

        break;
    }

    case WM_LBUTTONDOWN:
    {
        ReleaseCapture();
        SendMessage(hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        break;
    }

    case WM_COMMAND:
    {
        int controlId = LOWORD(wParam);

        if (controlId == ID_BTN_CLOSE)
        {
            DestroyWindow(hwnd);
            return 0;
        }

        if (controlId == ID_BTN_LOGIN)
        {
            std::string username = GetTextFromInput(txtUser);
            std::string password = GetTextFromInput(txtPass);

            if (username.empty() || password.empty())
            {
                SetStatus(hwnd, "Write username and password.", RGB(255, 210, 50));
                return 0;
            }

            HollowApp.login(username, password);

            if (HollowApp.response.success)
            {
                SetStatus(hwnd, "Login successful.", RGB(0, 255, 120));
                GoToMain(hwnd);
            }
            else
            {
                SetStatus(hwnd, HollowApp.response.message, RGB(255, 45, 45));
            }
        }

        if (controlId == ID_BTN_REGISTER)
        {
            std::string username = GetTextFromInput(txtUser);
            std::string password = GetTextFromInput(txtPass);
            std::string key = GetTextFromInput(txtKey);

            if (username.empty() || password.empty() || key.empty())
            {
                SetStatus(hwnd, "Complete user, pass and key.", RGB(255, 210, 50));
                return 0;
            }

            HollowApp.registerUser(username, password, key);

            if (HollowApp.response.success)
            {
                SetStatus(hwnd, "Registered. Now you can login.", RGB(0, 255, 120));
            }
            else
            {
                SetStatus(hwnd, HollowApp.response.message, RGB(255, 45, 45));
            }
        }

        if (controlId == ID_BTN_KEYLOGIN)
        {
            std::string key = GetTextFromInput(txtKey);

            if (key.empty())
            {
                SetStatus(hwnd, "Write a license key.", RGB(255, 210, 50));
                return 0;
            }

            HollowApp.license(key);

            if (HollowApp.response.success)
            {
                SetStatus(hwnd, "License valid.", RGB(0, 255, 120));
                GoToMain(hwnd);
            }
            else
            {
                SetStatus(hwnd, HollowApp.response.message, RGB(255, 45, 45));
            }
        }

        break;
    }

    case WM_DRAWITEM:
    {
        DrawOwnerButton((LPDRAWITEMSTRUCT)lParam);
        return TRUE;
    }

    case WM_CTLCOLOREDIT:
    {
        HDC hdcEdit = (HDC)wParam;
        SetTextColor(hdcEdit, RGB(255, 255, 255));
        SetBkColor(hdcEdit, RGB(0, 0, 0));

        static HBRUSH editBrush = CreateSolidBrush(RGB(0, 0, 0));
        return (INT_PTR)editBrush;
    }

    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        DrawLoginUI(hwnd, hdc);
        EndPaint(hwnd, &ps);
        break;
    }

    case WM_CLOSE:
        DestroyWindow(hwnd);
        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProcA(hwnd, msg, wParam, lParam);
    }

    return 0;
}

LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_CREATE:
        SetRoundedWindow(hwnd, 18);
        break;

    case WM_LBUTTONDOWN:
    {
        ReleaseCapture();
        SendMessage(hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        break;
    }

    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);

        RECT client;
        GetClientRect(hwnd, &client);

        HBRUSH bgBrush = CreateSolidBrush(RGB(0, 0, 0));
        FillRect(hdc, &client, bgBrush);
        DeleteObject(bgBrush);

        SetBkMode(hdc, TRANSPARENT);

        HFONT titleFont = CreateFontCustom(26, FW_BOLD);
        HFONT textFont = CreateFontCustom(15, FW_SEMIBOLD);

        SelectObject(hdc, titleFont);
        SetTextColor(hdc, RGB(255, 255, 255));
        TextOutA(hdc, 30, 28, "HollowAuth Main", 15);

        SelectObject(hdc, textFont);
        SetTextColor(hdc, RGB(180, 180, 180));

        std::string maintenance = HollowApp.variable("maintenance");
        std::string announcement = HollowApp.variable("announcement");

        if (maintenance.empty())
        {
            maintenance = "false";
        }

        if (announcement.empty())
        {
            announcement = "No announcement.";
        }

        std::string userLine = "User: " + HollowApp.user_data.username;
        std::string subLine = "Subscription: " + HollowApp.user_data.subscription;
        std::string expLine = "Expires: " + HollowApp.user_data.expires;

        TextOutA(hdc, 30, 85, userLine.c_str(), (int)userLine.length());
        TextOutA(hdc, 30, 118, subLine.c_str(), (int)subLine.length());
        TextOutA(hdc, 30, 151, expLine.c_str(), (int)expLine.length());
        std::string maintenanceLine = "Maintenance: " + maintenance;
        std::string announcementLine = "Announcement: " + announcement;

        TextOutA(hdc, 30, 190, maintenanceLine.c_str(), (int)maintenanceLine.length());
        TextOutA(hdc, 30, 223, announcementLine.c_str(), (int)announcementLine.length());

        DeleteObject(titleFont);
        DeleteObject(textFont);

        EndPaint(hwnd, &ps);
        break;
    }

    case WM_CLOSE:
        DestroyWindow(hwnd);
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProcA(hwnd, msg, wParam, lParam);
    }

    return 0;
}

void OpenMainWindow()
{
    const char mainClassName[] = "HollowAuthMainWindow";

    WNDCLASSEXA wc = {};
    wc.cbSize = sizeof(WNDCLASSEXA);
    wc.lpfnWndProc = MainWndProc;
    wc.hInstance = g_hInstance;
    wc.lpszClassName = mainClassName;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);

    RegisterClassExA(&wc);

    int width = 470;
    int height = 270;

    int screenX = GetSystemMetrics(SM_CXSCREEN);
    int screenY = GetSystemMetrics(SM_CYSCREEN);

    int x = (screenX - width) / 2;
    int y = (screenY - height) / 2;

    HWND mainWindow = CreateWindowExA(
        WS_EX_APPWINDOW,
        mainClassName,
        "HollowAuth Main",
        WS_POPUP,
        x,
        y,
        width,
        height,
        NULL,
        NULL,
        g_hInstance,
        NULL
    );

    ShowWindow(mainWindow, SW_SHOW);
    UpdateWindow(mainWindow);
}

int WINAPI WinMain(
    HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    LPSTR lpCmdLine,
    int nCmdShow
)
{
    g_hInstance = hInstance;

    GdiplusStartupInput gdiplusStartupInput;
    GdiplusStartup(&g_gdiplusToken, &gdiplusStartupInput, NULL);

    const char loginClassName[] = "HollowAuthLoginWindow";

    WNDCLASSEXA wc = {};
    wc.cbSize = sizeof(WNDCLASSEXA);
    wc.lpfnWndProc = LoginWndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = loginClassName;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);

    RegisterClassExA(&wc);

    int width = 340;
    int height = 560;

    int screenX = GetSystemMetrics(SM_CXSCREEN);
    int screenY = GetSystemMetrics(SM_CYSCREEN);

    int x = (screenX - width) / 2;
    int y = (screenY - height) / 2;

    g_loginWindow = CreateWindowExA(
        WS_EX_APPWINDOW,
        loginClassName,
        "HollowAuth",
        WS_POPUP,
        x,
        y,
        width,
        height,
        NULL,
        NULL,
        hInstance,
        NULL
    );

    ShowWindow(g_loginWindow, nCmdShow);
    UpdateWindow(g_loginWindow);

    MSG msg;

    while (GetMessageA(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessageA(&msg);
    }

    GdiplusShutdown(g_gdiplusToken);

    return 0;
}